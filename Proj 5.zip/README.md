# Ford Go Bike Data Exploration

## Dataset

There are 516988 ride entries in the dataset with 13 different variables initially.
Most variables are float type and some need to be converted from object to datetime, rest the data was almost clean.
Database download link: https://s3.amazonaws.com/baywheels-data/2017-fordgobike-tripdata.csv.zip

## Summary of Findings

In the exploration, i found out how each user type differs in rides counts and their traffic for each weekday and monthly, and from each other.

## Key Insights for Presentation

Plots chosen for the presentation was clean, short and very easy to interpret so that without the dataset open, one can unerstand and get insights quickly.
